public class VariableDeclaration {
    public static void main(String[] args) {
        // Declare and initialize variables
        int myInt = 10;
        double myDouble = 3.14;
        String myString = "Hello, World!";
        
        // Print the values of the variables
        System.out.println("Value of myInt: " + myInt);
        System.out.println("Value of myDouble: " + myDouble);
        System.out.println("Value of myString: " + myString);
    }
}
